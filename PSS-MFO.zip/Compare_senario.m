close all
clear all
clc

%% IAE
A=xlsread('results_leadlag','B3:B5');
p1=A(1);
p2=A(2);
p3=A(3);
sim('leadlag')
figure
plot(time,delta_w,'-.','LineWidth',1.5)
hold on
A=xlsread('results_pid','B3:B5');
kp=A(1);
ki=A(2);
kd=A(3);
sim('pid_1.slx')
plot(time,delta_w,'k','LineWidth',1.8)
hold on
A=xlsread('results_pi','B3:B4');
kp=A(1);
ki=A(2);
sim('pi_1.slx')
plot(time,delta_w,'r:','LineWidth',1.4)
legend('Lead-Lag','PID','PI')
xlabel('time (sec)')
ylabel('\Delta\omega (rad/sec)')
title('IAE criterion')
hold off

%% ITAE

A=xlsread('results_leadlag','D3:D5');
p1=A(1);
p2=A(2);
p3=A(3);
sim('leadlag')
figure
plot(time,delta_w,'-.','LineWidth',1.5)
hold on
A=xlsread('results_pid','D3:D5');
p1=A(1);
p2=A(2);
p3=A(3);
sim('pid_1.slx')
plot(time,delta_w,'k','LineWidth',1.8)
hold on
A=xlsread('results_pi','D3:D4');
kp=A(1);
ki=A(2);
sim('pi_1.slx')
plot(time,delta_w,'r:','LineWidth',1.4)
legend('Lead-Lag','PID','PI')
xlabel('time (sec)')
ylabel('\Delta\omega (rad/sec)')
title('ITAE criterion')
hold off 

%% ISE

A=xlsread('results_leadlag','F3:F5');
p1=A(1);
p2=A(2);
p3=A(3);
sim('leadlag')
figure
plot(time,delta_w,'-.','LineWidth',1.5)
hold on
A=xlsread('results_pid','F3:F5');
p1=A(1);
p2=A(2);
p3=A(3);
sim('pid_1.slx')
plot(time,delta_w,'k','LineWidth',1.8)
hold on
A=xlsread('results_pi','F3:F4');
kp=A(1);
ki=A(2);
sim('pi_1.slx')
plot(time,delta_w,'r:','LineWidth',1.4)
legend('Lead-Lag','PID','PI')
xlabel('time (sec)')
ylabel('\Delta\omega (rad/sec)')
title('ISE criterion')
hold off

%% ITSE

A=xlsread('results_leadlag','H3:H5');
p1=A(1);
p2=A(2);
p3=A(3);
sim('leadlag')
figure
plot(time,delta_w,'-.','LineWidth',1.5)
hold on
A=xlsread('results_pid','H3:H5');
p1=A(1);
p2=A(2);
p3=A(3);
sim('pid_1.slx')
plot(time,delta_w,'k','LineWidth',1.8)
hold on
A=xlsread('results_pi','H3:H4');
kp=A(1);
ki=A(2);
sim('pi_1.slx')
plot(time,delta_w,'r:','LineWidth',1.4)
legend('Lead-Lag','PID','PI')
xlabel('time (sec)')
ylabel('\Delta\omega (rad/sec)')
title('ITSE criterion')
hold off