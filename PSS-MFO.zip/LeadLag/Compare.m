clc
clear all
close all

A=xlsread('results_leadlag','B3:B5');
p1=A(1);
p2=A(2);
p3=A(3);
sim('leadlag.slx')
figure(1)
plot(time,delta_w,'LineWidth',1.85)
xlabel('time (sec)')
ylabel('\Delta\omega (rad/sec)')
legend('IAE')
figure(5)
plot(time,delta_w,':','LineWidth',1.85)
hold on
A=xlsread('results_leadlag','D3:D5');
p1=A(1);
p2=A(2);
p3=A(3);
sim('leadlag.slx')
figure(5)
plot(time,delta_w,'k','LineWidth',1.85)
hold on
figure(2)
plot(time,delta_w,'k','LineWidth',1.85)
xlabel('time (sec)')
ylabel('\Delta\omega (rad/sec)')
legend('ITAE')
A=xlsread('results_leadlag','F3:F5');
p1=A(1);
p2=A(2);
p3=A(3);
sim('leadlag.slx')
figure(5)
plot(time,delta_w,'r--','LineWidth',1.85)
hold on
figure(3)
plot(time,delta_w,'r','LineWidth',1.85)
xlabel('time (sec)')
ylabel('\Delta\omega (rad/sec)')
legend('ISE')
A=xlsread('results_leadlag','H3:H5');
p1=A(1);
p2=A(2);
p3=A(3);
sim('leadlag.slx')
figure(4)
plot(time,delta_w,'g','LineWidth',1.85)
xlabel('time (sec)')
ylabel('\Delta\omega (rad/sec)')
legend('ITSE')
figure(5)
plot(time,delta_w,'g-.','LineWidth',1.85)
xlabel('time (sec)')
ylabel('\Delta\omega (rad/sec)')
legend('IAE','ITAE','ISE','ITSE')